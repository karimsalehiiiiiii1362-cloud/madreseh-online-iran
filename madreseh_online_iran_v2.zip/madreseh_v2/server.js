const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
const defaultDb = { schoolOpen: true, classes: [{ id: '7-a', name: 'کلاس هفتم - گروه الف', code: 'IRAN7' }, { id: '8-a', name: 'کلاس هشتم - گروه الف', code: 'IRAN8' }], students: [], announcements: 'به مدرسه آنلاین ایران خوش آمدید.' };
function loadDb(){ try { return {...defaultDb, ...JSON.parse(fs.readFileSync(DB_FILE,'utf8'))}; } catch { saveDb(defaultDb); return structuredClone(defaultDb); } }
function saveDb(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2)); }
let db = loadDb();
const sessions = new Map();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeMe-123!';
function send(res, status, body, type='application/json; charset=utf-8'){ res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}); res.end(type.startsWith('application/json') ? JSON.stringify(body) : body); }
function parseCookies(req){ return Object.fromEntries((req.headers.cookie||'').split(';').map(v=>v.trim()).filter(Boolean).map(v=>{const i=v.indexOf('=');return [v.slice(0,i),decodeURIComponent(v.slice(i+1))]})); }
function isAdmin(req){ const id=parseCookies(req).sid; return !!id && sessions.get(id)==='admin'; }
function readBody(req){ return new Promise((resolve,reject)=>{let d=''; req.on('data',c=>{d+=c; if(d.length>1e6){reject(new Error('درخواست بیش از حد بزرگ است')); req.destroy();}}); req.on('end',()=>{try{resolve(d?JSON.parse(d):{})}catch{reject(new Error('فرمت درخواست معتبر نیست'))}});}); }
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(req.method==='GET' && url.pathname==='/api/status') return send(res,200,{schoolOpen:db.schoolOpen,classes:db.classes,announcements:db.announcements});
  if(req.method==='POST' && url.pathname==='/api/admin/login') { try { const b=await readBody(req); if(!crypto.timingSafeEqual(Buffer.from(String(b.password||'')),Buffer.from(ADMIN_PASSWORD))) return send(res,401,{error:'رمز مدیر نادرست است.'}); const id=crypto.randomBytes(24).toString('hex'); sessions.set(id,'admin'); res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Set-Cookie':`sid=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`,'Cache-Control':'no-store'}); return res.end(JSON.stringify({ok:true})); } catch(e){return send(res,400,{error:e.message});} }
  if(req.method==='POST' && url.pathname==='/api/admin/logout'){ const id=parseCookies(req).sid; sessions.delete(id); res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Set-Cookie':'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'}); return res.end('{"ok":true}'); }
  if(req.method==='GET' && url.pathname==='/api/admin/me') return send(res,200,{isAdmin:isAdmin(req)});
  if(req.method==='POST' && url.pathname.startsWith('/api/admin/')) { if(!isAdmin(req)) return send(res,401,{error:'ابتدا وارد پنل مدیر شوید.'});
    try { const b=await readBody(req);
      if(url.pathname==='/api/admin/school'){ db.schoolOpen=!!b.open; saveDb(db); return send(res,200,{ok:true,schoolOpen:db.schoolOpen}); }
      if(url.pathname==='/api/admin/announcement'){ db.announcements=String(b.text||'').slice(0,1000); saveDb(db); return send(res,200,{ok:true}); }
      if(url.pathname==='/api/admin/classes'){ const name=String(b.name||'').trim().slice(0,100); const code=String(b.code||'').trim().toUpperCase().replace(/[^A-Z0-9-]/g,'').slice(0,24); if(!name||code.length<4) return send(res,400,{error:'نام کلاس و کد حداقل ۴ حرفی لازم است.'}); if(db.classes.some(c=>c.code===code)) return send(res,409,{error:'این کد کلاس از قبل وجود دارد.'}); db.classes.push({id:crypto.randomUUID(),name,code}); saveDb(db); return send(res,200,{ok:true,classes:db.classes}); }
      if(url.pathname==='/api/admin/classes/delete'){ db.classes=db.classes.filter(c=>c.id!==b.id); saveDb(db); return send(res,200,{ok:true,classes:db.classes}); }
      return send(res,404,{error:'مسیر پیدا نشد.'});
    } catch(e){ return send(res,400,{error:e.message}); }
  }
  if(req.method==='POST' && url.pathname==='/api/student/join'){ try{ if(!db.schoolOpen) return send(res,403,{error:'مدرسه فعلاً تعطیل است؛ لطفاً بعداً مراجعه کنید.'}); const b=await readBody(req); const name=String(b.name||'').trim().slice(0,80); const code=String(b.code||'').trim().toUpperCase(); const cls=db.classes.find(c=>c.code===code); if(!name||!cls) return send(res,400,{error:'نام دانش‌آموز یا کد کلاس درست نیست.'}); const student={id:crypto.randomUUID(),name,className:cls.name,joinedAt:new Date().toISOString()}; db.students.push(student); saveDb(db); return send(res,200,{ok:true,message:`خوش آمدی ${name}!`,className:cls.name}); }catch(e){return send(res,400,{error:e.message});} }
  if(req.method==='GET' && url.pathname==='/api/admin/overview'){ if(!isAdmin(req)) return send(res,401,{error:'ابتدا وارد پنل مدیر شوید.'}); return send(res,200,{schoolOpen:db.schoolOpen,classes:db.classes,students:db.students,announcements:db.announcements}); }
  let file=url.pathname==='/'?path.join(ROOT,'public','index.html'):path.join(ROOT,'public',path.normalize(url.pathname).replace(/^([.][.][/\\])+/,'')); if(!file.startsWith(path.join(ROOT,'public'))) return send(res,403,'ممنوع','text/plain; charset=utf-8');
  fs.readFile(file,(err,data)=>{if(err)return send(res,404,'صفحه پیدا نشد','text/plain; charset=utf-8'); const ext=path.extname(file); send(res,200,data,ext==='.html'?'text/html; charset=utf-8':ext==='.css'?'text/css; charset=utf-8':ext==='.js'?'text/javascript; charset=utf-8':'application/octet-stream');});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Madreseh Online Iran running on port ${PORT}`));
